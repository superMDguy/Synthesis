/*
 * Copyright (c) AT&T Corp. 1994, 1995.
 * This code is licensed by AT&T Corp.  For the
 * terms and conditions of the license, see
 * http://www.research.att.com/orgs/ssr/book/reuse
 */

#pragma prototyped

#ifndef _C2L_H
#define _C2L_H
int C2Lopen (char *, char *, FILE **, FILE **);
#endif /* _C2L_H */
